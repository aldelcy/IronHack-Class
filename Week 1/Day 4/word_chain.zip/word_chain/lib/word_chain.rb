require "dictionary"

class WordChain
	
	def initialize(dictionary)
		@dictionary = dictionary 
	end

	def find_chain(start_word, end_word)

	end
end